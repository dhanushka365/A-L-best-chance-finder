#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int district();

int stream();

void file();

void enter_z_score();

void ascending_maths();
void ascending_bio();
void ascending_commerce();

void math_courses();
void bio_courses();
void commerce_courses();

void preparing_math_scores();
void preparing_bio_scores();
void preparing_commerce_scores();

int choice_maths();
int choice_bio();
int choice_commerce();

void extra_courses();

FILE *myFile;

int i,j,m=0;
float c,k;
float values[50];
int places[50];

int maths;
int bio;
int commerce;

int main(int argc, char *argv[]) {

   int x = -2;
   int y;
   char selection;
   printf("\t\t\tUniversity grant commission - Srilanka\t \n \t\t\tApplication for academic year - 2015/2016\n\n\n");

   x = district();

   if ((x>0) && (x<=25)){

      while(selection != '3'){
	      printf("select your options\n");
	      printf("1: Enter your stream\n");
	      printf("2: Enter your z score\n");
	      printf("3: Finish\n");
	      scanf(" %c",&selection);
	      switch(selection){
	   	  case '1': y = stream();break;
	   	  case '2': file(x,y);break;
	      }
   	  }

   }

	return 0;
}

int district(){

	char district[20];
	int x = -2;

	printf("enter your district (Please use simple letters only \n & do not keep spaces eg: colombo) ");
    scanf("%[^\n]s",&district);

	if (strcmp(district,"colombo") == 0){
		x = 1;
	}else if(strcmp(district,"gampaha") == 0){
		x = 2;
	}else if(strcmp(district,"kalutara") == 0){
		x = 3;
	}else if(strcmp(district,"matale") == 0){
		x = 4;
	}else if(strcmp(district,"kandy") == 0){
		x = 5;
	}else if(strcmp(district,"nuwaraeliya") == 0){
		x = 6;
	}else if(strcmp(district,"galle") == 0){
		x = 7;
	}else if(strcmp(district,"matara") == 0){
		x = 8;
	}else if(strcmp(district,"hambantota") == 0){
		x = 9;
	}else if(strcmp(district,"jaffna") == 0){
		x = 10;
	}else if(strcmp(district,"kilinochchi") == 0){
		x = 11;
	}else if(strcmp(district,"mannar") == 0){
		x = 12;
	}else if(strcmp(district,"mullaitivu") == 0){
		x = 13;
	}else if(strcmp(district,"vavuniya") == 0){
		x = 14;
	}else if(strcmp(district,"trincomalee") == 0){
		x = 15;
	}else if(strcmp(district,"batticaloa") == 0){
		x = 16;
	}else if(strcmp(district,"ampara") == 0){
		x = 17;
	}else if(strcmp(district,"puttalam") == 0){
		x = 18;
	}else if(strcmp(district,"kurunegala") == 0){
		x = 19;
	}else if(strcmp(district,"anuradhapura") == 0){
		x = 20;
	}else if(strcmp(district,"polonnaruwa") == 0){
		x = 21;
	}else if(strcmp(district,"badulla") == 0){
		x = 22;
	}else if(strcmp(district,"monaragala") == 0){
		x = 23;
	}else if(strcmp(district,"kegalle") == 0){
		x = 24;
	}else if(strcmp(district,"Ratnapura") == 0){
		x = 25;
	}else{
		printf("wrong district or incorrect spelling, \n start the program from the begining\n\n");
	}

	return x;

}

int stream(){
   char select = '0';
   int sel =  0;
   while(1){

	   printf("Enter your A/L stream\n\n");
	   printf("enter\n\n");
	   printf(" a for Maths\n b for bio \n c for commerce\n\n");

	   //select = getchar();
	   scanf(" %c",&select);


	   if((select == 'a')||(select== 'b')||(select=='c')){
	   	    break;

	   }

   }

    switch(select){

    	case 'a': sel =1; break;
    	case 'b': sel =2; break;
    	case 'c': sel =3; break;
	}
	  return sel;

}

void file(int a, int b){

	enter_z_score();

	switch (b){

	  case 1:{

	    myFile = fopen("C:\\Users\\97\\3D Objects\\New folder (2)\\maths.txt", "r");

	    preparing_math_scores(a);

		ascending_maths();
		maths = choice_maths();

		math_courses();
		extra_courses(b);

		    break;
	}case 2:{

		myFile = fopen("C:\\Users\\97\\3D Objects\\New folder (2)\\bio.txt", "r");

	    preparing_bio_scores(a);

		ascending_bio();
		bio = choice_bio();
		bio_courses();
		extra_courses(b);

		    break;

	}case 3:{

		myFile = fopen("C:\\Users\\97\\3D Objects\\New folder (2)\\commerce.txt", "r");

		preparing_commerce_scores(a);

		ascending_commerce();
		commerce = choice_commerce();

		commerce_courses();
		extra_courses(b);

			break;
	}
}

	fclose(myFile);

}

void enter_z_score(){

	printf("enter your z-score\n\n");
   	scanf(" %f",&c);
   	printf("your z score is taken as %.3f\n",c);

}

void ascending_maths(){

	for(i = 0; i< 26; i++){
		    for(j=0; j<25; j++){
		    	if(values[j] < values[j+1]){
		    		k = values[j];
		    		m = places[j];
		    		values[j] = values[j+1];
		    		values[j+1] = k;
		    		places[j] = places[j+1];
		    		places[j+1] = m;
				}
			}
	}

	printf("-999 is for courses you are not qualified\n\n\n");
}


void ascending_bio(){

	for(i = 0; i< 26; i++){
		    for(j=0; j<25; j++){
		    	if(values[j] < values[j+1]){
		    		k = values[j];
		    		m = places[j];
		    		values[j] = values[j+1];
		    		values[j+1] = k;
		    		places[j] = places[j+1];
		    		places[j+1] = m;
				}
			}
	}
	printf("-999 is for courses you are not qualified\n\n\n");

}

void ascending_commerce(){
	for(i = 0; i< 19; i++){
		    for(j=0; j<18; j++){
		    	if(values[j] < values[j+1]){
		    		k = values[j];
		    		m = places[j];
		    		values[j] = values[j+1];
		    		values[j+1] = k;
		    		places[j] = places[j+1];
		    		places[j+1] = m;
				}
			}
	}
	printf("-999 is for courses you are not qualified\n\n\n");

}

int choice_maths(){
	char choice;
	printf("Did you select IT as your optional subject?\nIf yes press y else press n\n\n");
	while(1){
	printf("press y or n to select and continue\n\n");
	scanf(" %c",&choice);
	 if((choice == 'y')||(choice == 'n'))
	 break;
	}
		if(choice == 'y'){
			return 1;
		}else if(choice == 'n'){
			return 0;
		}

}

int choice_bio(){
	char choice;
	printf("Did you select Agri as your optional subject?\nIf yes press y else press n\n\n");
	while(1){
	printf("press y or n to select and continue\n\n");
	scanf(" %c",&choice);
	 if((choice == 'y')||(choice == 'n'))
	 break;
	}
		if(choice == 'y'){
			return 1;
		}else if(choice == 'n'){
			return 0;
		}

}

int choice_commerce(){
	char choice;
	printf("Did you select Accountancy as a subject?\nIf yes press y else press n\n\n");
	while(1){
	printf("press y or n to select and continue\n\n");
	scanf(" %c",&choice);
	 if((choice == 'y')||(choice == 'n'))
	 break;
	}
		if(choice == 'y'){
			return 1;
		}else if(choice == 'n'){
			return 0;
		}


}

void math_courses(){

	for (j = 0; j < 26; j++){
		        /*printf("%f\t\t%d\n", values[j],places[j]);*/
			        if(values[j]<-6){
			        	values[j] = -999;
					}
					if((maths == 1)&&(places[j]<16)){
		        		values[j] = -999;
					}

		        switch(places[j]){

		        	case 0: printf("Peradeniya Engineering......................%f\n",values[j]); break;
		        	case 1: printf("Jayawardenepura Engineering.................%f\n",values[j]); break;
		        	case 2: printf("Jaffna Engineering..........................%f\n",values[j]); break;
		        	case 3: printf("Ruhuna Engineering..........................%f\n",values[j]); break;
		        	case 4: printf("Moratuwa Engineering........................%f\n",values[j]); break;
		        	case 5: printf("South Eatsern Engineering...................%f\n",values[j]); break;
		        	case 6: printf("Moratuwa Earth Resource Engineering.........%f\n",values[j]); break;
		        	case 7: printf("Moratuwa Textile and Clothing...............%f\n",values[j]); break;
		        	case 8: printf("Colombo physical............................%f\n",values[j]); break;
		        	case 9: printf("Peradeniya physical.........................%f\n",values[j]); break;
		        	case 10:printf("Jayawardenepura physical....................%f\n",values[j]); break;
		        	case 11:printf("Kelaniya physical...........................%f\n",values[j]); break;
		        	case 12:printf("Jaffna physical.............................%f\n",values[j]); break;
		        	case 13:printf("Ruhuna physical.............................%f\n",values[j]); break;
		        	case 14:printf("Eastern physical............................%f\n",values[j]); break;
		        	case 15:printf("South Eastern physical......................%f\n",values[j]); break;
		        	case 16:printf("Kelaniya Computer science...................%f\n",values[j]); break;
		        	case 17:printf("Jaffna Computer science.....................%f\n",values[j]); break;
		        	case 18:printf("Ruhuna Computer science.....................%f\n",values[j]); break;
		        	case 19:printf("Colombo(UCSC) Computer science..............%f\n",values[j]); break;
		        	case 20:printf("Eastern Computer science....................%f\n",values[j]); break;
		        	//case 22:printf("Rajarata ICT................................%f + Aplitude test\n",values[j]); break;
		        	//case 23:printf("Jaffna(Vavuniya) ICT........................%f + Aplitude test\n",values[j]); break;
		        	case 21:printf("Rajarata Applied Science....................%f\n",values[j]); break;
		        	case 22:printf("Sabaragamuwa Applied Science................%f\n",values[j]); break;
		        	case 23:printf("Wayamba Applied Science.....................%f\n",values[j]); break;
		        	case 24:printf("Jaffna Applied Science......................%f\n",values[j]); break;
		        	case 25:printf("Eastern Applied Science.....................%f\n",values[j]); break;
				}
		        //printf("\n%f",values[j]);
	}

}


void bio_courses(){
	for (j = 0; j < 26; j++){
		        /*printf("%f\t\t%d\n", values[j],places[j]);*/
			        if(values[j]<-6){
			        	values[j] = -999;
					}
					if((bio == 1)&&(places[j]<10)){
		        		values[j] = -999;
					}

		        switch(places[j]){

		        	case 0: printf("Colombo Medicine...............................%f\n",values[j]); break;
		        	case 1: printf("Peradeniya Medicine............................%f\n",values[j]); break;
		        	case 2: printf("Jayewardenepura Medicine.......................%f\n",values[j]); break;
		        	case 3: printf("Kelaniya Medicine..............................%f\n",values[j]); break;
		        	case 4: printf("Jaffna Medicine................................%f\n",values[j]); break;
		        	case 5: printf("Ruhuna Medicine................................%f\n",values[j]); break;
		        	case 6: printf("Eastern Medicine...............................%f\n",values[j]); break;
		        	case 7: printf("Rajarata Medicine..............................%f\n",values[j]); break;
		        	case 8: printf("Peradeniya Dental Surgery......................%f\n",values[j]); break;
		        	case 9: printf("Peradeniya Veterinary..........................%f\n",values[j]); break;
		        	case 10:printf("Colombo Molecular Biology & Biochemistry.......%f\n",values[j]); break;
		        	case 11:printf("Peradeniya Agricultural Technology & Manag.....%f\n",values[j]); break;
		        	case 12:printf("Jaffna Agriculture.............................%f\n",values[j]); break;
		        	case 13:printf("Eastern Agriculture............................%f\n",values[j]); break;
		        	case 14:printf("Rajarata Agriculture...........................%f\n",values[j]); break;
		        	case 15:printf("Sabaragamuwa Agriculture.......................%f\n",values[j]); break;
		        	case 16:printf("Wayamba  Agriculture...........................%f\n",values[j]); break;
		        	case 17:printf("Wayamba Food Science & Nutrition............ ..%f\n",values[j]); break;
		        	case 18:printf("Peradeniya Food Science & Technology...........%f\n",values[j]); break;
		        	case 19:printf("Jayewardenepura Food Science & Technology......%f\n",values[j]); break;
		        	case 20:printf("Sabaragamuwa Food Science & Technology.........%f\n",values[j]); break;
		        	case 21:printf("Jayewardenepura Biological Science.............%f\n",values[j]); break;
		        	case 22:printf("Kalaniya Biological Science....................%f\n",values[j]); break;
		        	case 23:printf("Jaffna Biological Science......................%f\n",values[j]); break;
		        	case 24:printf("Ruhuna Biological Science......................%f\n",values[j]); break;
		        	case 25:printf("Eastern Biological Science.....................%f\n",values[j]); break;
				}
		        //printf("\n%f",values[j]);
	}


}

void commerce_courses(){
	for (j = 0; j < 19; j++){
		        /*printf("%f\t\t%d\n", values[j],places[j]);*/
			        if(values[j]<-6){
			        	values[j] = -999;
					}
					if((commerce == 0)&&(places[j]>12)){
		        		values[j] = -999;
					}

		        switch(places[j]){

		        	case 0: printf("Colombo Management..............................................%f\n",values[j]); break;
		        	case 1: printf("Peradeniya Management...........................................%f\n",values[j]); break;
		        	case 2: printf("Jayawardenepura Management......................................%f\n",values[j]); break;
		        	case 3: printf("Kelaniya Management.............................................%f\n",values[j]); break;
		        	case 4: printf("Jaffna Management...............................................%f\n",values[j]); break;
		        	case 5: printf("Ruhuna Management...............................................%f\n",values[j]); break;
		        	case 6: printf("Eastern Management..............................................%f\n",values[j]); break;
		        	case 7: printf("South Eastern Management........................................%f\n",values[j]); break;
		        	case 8: printf("Rajarata Management.............................................%f\n",values[j]); break;
		        	case 9: printf("Sabaragamuwa Management.........................................%f\n",values[j]); break;
		        	case 10:printf("Wayamba Management..............................................%f\n",values[j]); break;
		        	case 11:printf("Jayawardenepura Estate Management & Valuation...................%f\n",values[j]); break;
		        	case 12:printf("Jayawardenepura Commerce........................................%f\n",values[j]); break;
		        	case 13:printf("Kalaniya Commerce...............................................%f\n",values[j]); break;
		        	case 14:printf("Jaffna Commerce.................................................%f\n",values[j]); break;
		        	case 15:printf("Eastern Commerce................................................%f\n",values[j]); break;
		        	case 16:printf("South Eastern Commerce..........................................%f\n",values[j]); break;
		        	case 17:printf("Jayawardenepura Management(Public)(Special).....................%f\n",values[j]); break;
		        	case 18:printf("Jayawardenepura Business Information Systems....................%f\n",values[j]); break;

				}
		        //printf("\n%f",values[j]);
	}


}


void preparing_math_scores(int a){

	float numberArray[25][26];

		if (myFile == NULL){
	        printf("Error Reading File\n");
	        exit (0);
	    }

		for (i = 0; i < 12; i++){
	    	for (j = 0; j <26; j++){
	        	fscanf(myFile, "%f", &numberArray[i][j] );
	    	}
	    }

	    a--;
	    i = a;

		for (j = 0; j < 26; j++){
	        printf("Number is: %.3f\n\n", numberArray[i][j]);

	        values[j] = c - numberArray[i][j];

	        places[j] = j;
	    }
}

void preparing_bio_scores(int a){

	float numberArray[25][26];

		if (myFile == NULL){
	        printf("Error Reading File\n");
	        exit (0);
	    }

		for (i = 0; i < 12; i++){
	    	for (j = 0; j <26; j++){
	        	fscanf(myFile, "%f", &numberArray[i][j] );
	    	}
	    }

	    a--;
	    i = a;

		for (j = 0; j < 26; j++){
	        printf("Number is: %.3f\n\n", numberArray[i][j]);

	        values[j] = c - numberArray[i][j];

	        places[j] = j;
	    }
}

void preparing_commerce_scores(int a){

	float numberArray[25][19];

		if (myFile == NULL){
	        printf("Error Reading File\n");
	        exit (0);
	    }

		for (i = 0; i < 12; i++){
	    	for (j = 0; j <19; j++){
	        	fscanf(myFile, "%f", &numberArray[i][j] );
	    	}
	    }

	    a--;
	    i = a;

		for (j = 0; j < 19; j++){
	        printf("Number is: %.3f\n\n", numberArray[i][j]);

	        values[j] = c - numberArray[i][j];

	        places[j] = j;
	    }
}


void extra_courses(int b){

	char o;
	int p=0,q=0,r=0;
	int ttt[40];


	printf("\n\nDo you want to see the optional courses you are selected?\n");
	printf("If yes press 1, if no press any number to end\n");
	scanf(" %c",&o);

	if(o == '1'){
       if(b == 1){
	     for(p=0;p<=40;p++){
	     	if(p<=33){
	     		ttt[q]=p;
	     		q++;
			}
		 }
	   }else if(b == 2){
	   	for(p=0;p<=40;p++){
	     	if((q<=30)||(q>33)){
	     		ttt[q]=p;
	     		q++;
			}
		 }
	   }else{
	   	 for(p=0;p<=40;p++){
	     	if((p<=15)||(p==21)||(p==23)||(p==25)||(p==26)||(p==27)||(p==28)){
	     		ttt[q]=p;
	     		q++;
			}
		 }
	   }
       	r = q -1;
       	q = 0;
       	while(r>=q){
       	 switch(ttt[q]){
	       case 1: printf("Architecture \n");break;
		   case 2: printf("Design (Architecture) \n");break;
		   case 3: printf("Fashion Design & Product Development\n");break;
		   case 4: printf("Quantity Surveying  \n");break;
		   case 5: printf("Information Technology \n");break;
		   case 6: printf("Management & Information Technology\n");break;
		   case 7: printf("Physiotherapy \n");break;
		   case 8: printf("Management Studies (TV)\n");break;
		   case 9: printf("Law\n");break;
		   case 10: printf("Town & Country  Planning   \n");break;
		   case 11: printf("Peace   &  Conflict  Resolution \n");break;
		   case 12: printf("Information & Communication Technology\n");break;
		   case 13: printf("Facilities  Management \n");break;
		   case 14: printf("Entrepre-neurship & Management\n");break;
		   case 15: printf("Computation & Management\n");break;
		   case 16: printf("Tea Technology & Value Addition \n");break;
		   case 17: printf("Industrial Information Technology\n");break;
		   case 18: printf("Mineral Resources & Technology \n");break;
		   case 19: printf("Management and Information Technology (SEUSL)\n");break;
		   case 20: printf("Physical Education\n");break;
		   case 21: printf("Sports Science & Management \n");break;
		   case 22: printf("Speech and Hearing Sciences \n");break;
		   case 23: printf("Computing & Information  Systems\n");break;
		   case 24: printf("Hospitality, Tourism and  Events Management   \n");break;
		   case 25: printf("Palm and Latex Technology and Value Addition \n");break;
		   case 26: printf("Information Technology & Management\n");break;
		   case 27: printf("Information Systems\n");break;
		   case 28: printf("Translation Studies  \n");break;
		   case 29: printf("Science and technology\n");break;
		   case 30: printf("Software Engineering\n");break;
		   case 31: printf("Industrial Statistics  &  Mathematical Finance\n");break;
		   case 32: printf("Statistics  &  Operations  Research\n");break;
		   case 33: printf("Transport & Logistics Management \n");break;
		   case 34: printf("Animal Science\n");break;
		   case 35: printf("Export Agriculture\n");break;
		   case 36: printf("Agric Business Management\n");break;
		   case 37: printf("Food  Production and Technology Management\n");break;
		   case 38: printf("Green Technology\n");break;
		   case 39: printf("Agricultural Resource Management & Technology \n");break;
		   case 40: printf("Animal Science & Fisheries\n");break;

	 	 }
	 	 q++;
	  }
	}

}









